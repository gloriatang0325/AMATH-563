%Lorenz

%% training
x0=30*(rand(3,1)-0.5);
[t10,y10]=Lorenz(x0,10);
[t28,y28]=Lorenz(x0,28);
[t40,y40]=Lorenz(x0,40);
y=[y10,y8,y40];
for j=1:100
    input=[input; y(1:end-1,:)];
    output=[output; y(2:end,:)];
end
net = feedforwardnet([10 10 10]);
net.layers{1}.transferFcn = 'logsig';
net.layers{2}.transferFcn = 'radbas';
net.layers{3}.transferFcn = 'purelin';
net = train(net,input.',output.');

%% testing
x0=30*(rand(3,1)-0.5);
[t17,y17]=Lorenz(17);
[t35,y35]=Lorenz(35);
ynn(1,:)=x0;
for jj=2:length(t)
    y0=net(x0);
    ynn(jj,:)=y0.'; x0=y0;
end
plot3(y17(:,1),y17(:,2),y17(:,3),':','Linewidth',[2]);
plot3(y35(:,1),y35(:,2),y35(:,3),':','Linewidth',[2]);
plot3(ynn(:,1),ynn(:,2),ynn(:,3),':','Linewidth',[2]);
