clear all, close all, clc

%Train a NN that can advance the solution from t to t + ∆t for the KS equation
n=[4,8,16,20];
[uu1,tt1,x1]=odetime(4);
[uu2,tt2,x2]=odetime(8);
[uu,tt,x]=odetime(16);
[uu4,tt4,x4]=odetime(20);
input= uu(:,1:end-1);
output= uu(:,2:end);

net = feedforwardnet([10 10 10]);
net.layers{1}.transferFcn = 'logsig';
net.layers{2}.transferFcn = 'radbas';
net.layers{3}.transferFcn = 'purelin';
net=train(net,input,output);

%Compare your evolution trajectories for your NN against using the ODE time-stepper provided with different initial conditions

%%
x10=uu1(:,1);
ynn1(:,1)=x10;
for jj=2:length(tt1)
    y0=net(x10);
    ynn1(jj,:)=y0; x10=y0;
end
surf(x,tt,uu), shading interp, colormap(hot), axis tight 
surf(tt1,x1,ynn1), shading interp, colormap(hot), axis tight 
%%
x20=uu2(:,1);
ynn2(:,1)=x20;
for jj=2:length(tt2)
    y0=net(x20);
    ynn1(jj,:)=y0; x20=y0;
end
surf(x,tt,uu), shading interp, colormap(hot), axis tight 
surf(tt2,x2,ynn2), shading interp, colormap(hot), axis tight 
%%
x40=uu4(:,1);
ynn4(:,1)=x40;
for jj=2:length(tt4)
    y0=net(x40);
    ynn4(jj,:)=y0; x40=y0;
end
surf(x,tt,uu), shading interp, colormap(hot), axis tight 
surf(tt4,x4,ynn4), shading interp, colormap(hot), axis tight 