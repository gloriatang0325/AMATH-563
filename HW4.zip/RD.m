%For the reaction-diffusion system,ﬁrst project to a low-dimensional subspace via the SVD 
clear all; close all; clc
reaction_diffusion;
KS;

for i=1:length(t)
    U(:,i)=reshape(u(:,:,i),n*n,1);
    V(:,i)=reshape(v(:,:,i),n*n,1);
end
[U1,S1,V1]=svd(U);
[U2,S2,V2]=svd(V);
pred_U=net(U1.'.*U);
pred_V=net(U2.'.*V);
U_pred=U1.*pred_U;
V_pred=U2.*pred_V;
